# Catálogos de NLDMAP

Exportación del MongoDB local de desarrollo del 24 de noviembre de 2026.

- `valores.md` contiene los valores de todos los catálogos pequeños y el inventario completo.
- `datos/inventario.tsv` contiene el número de registros por colección.
- `datos/*.jsonl` contiene un documento por línea en MongoDB Extended JSON v2 canónico. Cada archivo lleva el nombre de su colección. Este formato conserva los tipos BSON y los identificadores `_id`.

Se incluyen los catálogos históricos de sexo, estado de revisión y tipo de circunstancia con sus nombres de colección originales. Se omitieron las referencias de auditoría a cuentas y los campos antiguos del catálogo de vehículos que el formulario actual captura por reporte. El paquete contiene datos de catálogo. La exportación se hizo por colección y los archivos contienen documentos, por lo que los índices y validadores del destino se gestionan por separado.

## Importar a otra base MongoDB

Descomprime el ZIP. Abre una terminal en la carpeta que contiene `datos` y usa MongoDB Database Tools. En el ejemplo, `MONGO_URI_DESTINO` apunta al servidor de destino y `BASE_DESTINO` identifica una base vacía. Si la URI incluye el nombre de una base, usa ese mismo nombre en `BASE_DESTINO`.

```sh
(
  set -eu
  : "${MONGO_URI_DESTINO:?Configura la URI de MongoDB de destino}"
  : "${BASE_DESTINO:?Configura el nombre de la base de destino}"

  for archivo in datos/*.jsonl; do
    coleccion=$(basename "$archivo" .jsonl)
    mongoimport --uri "$MONGO_URI_DESTINO" --db "$BASE_DESTINO" \
      --collection "$coleccion" --file "$archivo" --type json \
      --mode insert --stopOnError
  done
)
```

El modo de inserción conserva los documentos que ya existan y detiene la importación de la colección ante un ID duplicado. Tras la carga, compara los conteos de las colecciones con `datos/inventario.tsv` y configura la aplicación para apuntar a la base de destino.

[Documentación oficial de mongoimport](https://www.mongodb.com/docs/database-tools/mongoimport/)
