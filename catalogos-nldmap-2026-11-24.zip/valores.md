# Valores de los catálogos de NLDMAP

19 colecciones y 204 documentos exportados.

| Colección | Registros |
|---|---:|
| `catalogo_circunstancia` | 7 |
| `catalogo_color` | 16 |
| `catalogo_complexion` | 3 |
| `catalogo_discapacidad` | 7 |
| `catalogo_genero` | 3 |
| `catalogo_nacionalidad` | 26 |
| `catalogo_ocupacion` | 12 |
| `catalogo_orientacion_sexual` | 8 |
| `catalogo_parentesco` | 22 |
| `catalogo_region_corporal` | 18 |
| `catalogo_tez` | 10 |
| `catalogo_tipo_cabello` | 15 |
| `catalogo_tipo_calzado` | 10 |
| `catalogo_tipo_prenda` | 16 |
| `catalogo_tipo_sena` | 7 |
| `catalogo_vehiculo` | 19 |
| `catalogo_sexo` | 2 |
| `catalogo_estado_revision` | 1 |
| `catalogo_tipo_circunstancia` | 2 |

## catalogo_circunstancia

| tipo | descripcionCircunstancia |
| --- | --- |
| Circunstancia desconocida | Se desconoce la circunstancia en la que se perdió el contacto. |
| No regresó a su domicilio | Se esperaba que la persona regresara a su domicilio. |
| Otra circunstancia | Consulta la descripción de los hechos. |
| Pérdida de contacto cerca del domicilio | El último contacto se tuvo en el domicilio o sus alrededores. |
| Pérdida de contacto durante un traslado | El último contacto se tuvo mientras la persona se desplazaba. |
| Pérdida de contacto durante un viaje | El último contacto se tuvo durante un viaje. |
| Pérdida de contacto en el trabajo o la escuela | El último contacto se tuvo en un contexto laboral o escolar. |

## catalogo_color

| colorNombre | colorHex |
| --- | --- |
| Amarillo | #FBC02D |
| Azul | #1565C0 |
| Azul marino | #1A237E |
| Beige | #D7C2A8 |
| Blanco | #FFFFFF |
| Café | #795548 |
| Dorado | #C9A227 |
| Gris | #808080 |
| Guinda | #800020 |
| Morado | #6A1B9A |
| Naranja | #EF6C00 |
| Negro | #000000 |
| Plateado | #C0C0C0 |
| Rojo | #C62828 |
| Rosa | #D81B60 |
| Verde | #2E7D32 |

## catalogo_complexion

| nombreComplexion |
| --- |
| Delgada |
| Media |
| Robusta |

## catalogo_discapacidad

| nombreDiscapacidad |
| --- |
| Auditiva |
| Física o motriz |
| Intelectual |
| Múltiple |
| Otra |
| Psicosocial |
| Visual |

## catalogo_genero

| nombreSexo |
| --- |
| Femenino |
| Masculino |
| No especificado |

## catalogo_nacionalidad

| nombreNacionalidad |
| --- |
| Argentina |
| Beliceña |
| Boliviana |
| Brasileña |
| Canadiense |
| Chilena |
| Colombiana |
| Costarricense |
| Cubana |
| Dominicana |
| Ecuatoriana |
| Española |
| Estadounidense |
| Guatemalteca |
| Haitiana |
| Hondureña |
| Mexicana |
| Nicaragüense |
| No especificada |
| Otra |
| Panameña |
| Paraguaya |
| Peruana |
| Salvadoreña |
| Uruguaya |
| Venezolana |

## catalogo_ocupacion

| nombreOcupacion | descripcionOcupacion |
| --- | --- |
| Comerciante | Realiza actividades de compraventa. |
| Docente | Realiza actividades de enseñanza. |
| Empleado administrativo | Realiza labores de oficina o gestión. |
| Estudiante | Cursa estudios. |
| Jubilado | Persona retirada de una actividad laboral. |
| Operador de transporte | Trabaja en el transporte de personas o mercancías. |
| Otra | Ocupación indicada en la descripción del reporte. |
| Personal de salud | Trabaja en la atención, prevención o servicios de salud. |
| Sin ocupación registrada | No se cuenta con un dato de ocupación. |
| Trabajador agrícola | Realiza labores agrícolas. |
| Trabajador de la construcción | Realiza labores de construcción. |
| Trabajo del hogar | Realiza labores domésticas o de cuidados. |

## catalogo_orientacion_sexual

| nombreOrientacionSexual | descripcionOrientacionSexual |
| --- | --- |
| Asexual | Experimenta poca o ninguna atracción sexual. |
| Bisexual | Atracción hacia personas de más de un género. |
| Gay | Término de autoidentificación asociado con la atracción hacia personas del mismo género. |
| Heterosexual | Atracción hacia personas de un género distinto. |
| Lesbiana | Mujer que siente atracción hacia otras mujeres. |
| No especificada | La orientación sexual se desconoce o no se indicó. |
| Otra | Otra orientación sexual indicada por la persona. |
| Pansexual | Atracción que puede darse independientemente del género. |

## catalogo_parentesco

| nombreParentesco |
| --- |
| Abuela |
| Abuelo |
| Amistad |
| Cónyuge |
| Hermana |
| Hermano |
| Hija |
| Hijo |
| Madre |
| Nieta |
| Nieto |
| Otro vínculo |
| Padre |
| Pareja |
| Persona conocida |
| Prima |
| Primo |
| Sin vínculo |
| Sobrina |
| Sobrino |
| Tía |
| Tío |

## catalogo_region_corporal

| region |
| --- |
| Abdomen |
| Brazo |
| Brazo derecho |
| Brazo izquierdo |
| Cabeza |
| Cadera |
| Cuello |
| Espalda |
| Hombro derecho |
| Hombro izquierdo |
| Mano derecha |
| Mano izquierda |
| Pecho |
| Pie derecho |
| Pie izquierdo |
| Pierna derecha |
| Pierna izquierda |
| Rostro |

## catalogo_tez

| colorPiel | colorHex |
| --- | --- |
| Monk 01 | #F6EDE4 |
| Monk 02 | #F3E7DB |
| Monk 03 | #F7EAD0 |
| Monk 04 | #EADABA |
| Monk 05 | #D7BD96 |
| Monk 06 | #A07E56 |
| Monk 07 | #825C43 |
| Monk 08 | #604134 |
| Monk 09 | #3A312A |
| Monk 10 | #292420 |

## catalogo_tipo_cabello

| nombreCabello | largoCabello |
| --- | --- |
| Lacio | Corto |
| Lacio | Largo |
| Lacio | Medio |
| Muy rizado · corto | Corto |
| Muy rizado · largo | Largo |
| Muy rizado · medio | Medio |
| No especificado | No especificado |
| Ondulado · corto | Corto |
| Ondulado · largo | Largo |
| Ondulado · medio | Medio |
| Rapado | Rapado |
| Rizado · corto | Corto |
| Rizado · largo | Largo |
| Rizado · medio | Medio |
| Sin cabello | Sin cabello |

## catalogo_tipo_calzado

| nombreCalzado |
| --- |
| Botas |
| Huaraches |
| Mocasines |
| Otro |
| Pantuflas |
| Sandalias |
| Sin calzado |
| Tenis |
| Zapatos |
| Zapatos de tacón |

## catalogo_tipo_prenda

| nombre |
| --- |
| Abrigo |
| Blusa |
| Camisa |
| Chaleco |
| Chamarra |
| Falda |
| Gorra |
| Otra |
| Pantalón |
| Pantalón de mezclilla |
| Playera |
| Short |
| Sudadera |
| Suéter |
| Uniforme |
| Vestido |

## catalogo_tipo_sena

| nombre |
| --- |
| Cicatriz |
| Lunar |
| Mancha |
| Marca de nacimiento |
| Otra |
| Perforación |
| Tatuaje |

## catalogo_vehiculo

| marca |
| --- |
| BMW |
| Chevrolet |
| Dodge |
| Ford |
| Honda |
| Hyundai |
| Jeep |
| Kia |
| Mazda |
| Mercedes-Benz |
| Mitsubishi |
| Nissan |
| Otra |
| RAM |
| Renault |
| SEAT |
| Suzuki |
| Toyota |
| Volkswagen |

## catalogo_sexo

| nombre |
| --- |
| Femenino |
| Masculino |

## catalogo_estado_revision

| nombre |
| --- |
| Pendiente de revisión |

## catalogo_tipo_circunstancia

| nombre | descripcion |
| --- | --- |
| Desaparicion Forzada | Fue privada de su libertad |
| Desaparicion Voluntaria | Abandono su hogar de forma voluntaria |
